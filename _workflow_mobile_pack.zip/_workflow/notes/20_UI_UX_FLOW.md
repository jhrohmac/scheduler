# 1. 화면(UI/UX) 단위 플로우

## 1-1 관심종목(Watchlist)
- 목적: 리스트에서 현재시점의 종목 분석상태/시그널/레짐을 빠르게 확인
- 입력: 관심종목 그룹/종목, 실시간(옵션)
- 출력: 종목 카드/리스트, 상태 배지(예: 분석 최신시각, 신호, 레짐)
- 연관 DB: TB_S_INTEREST_STOCK, (실시간) 캐시/WS, TB_S_STOCK_ANALYSIS, TB_S_STOCK_30MINANALYSIS

## 1-2 추천종목(Recommend)
- 목적: 점수/등급 기반 Top-N 추천 + 추천 사유(이벤트 요약) 확인
- 입력: market/minGrade/domMarket/limit/가격필터/현재가옵션
- 출력: 추천 리스트 + 레짐 배너 + reco_event_summary
- 연관 로직: 2-3 추천 종목 선별
- 연관 DB: TB_S_STOCK_ANALYSIS, TB_S_STOCK_30MINANALYSIS, TB_S_SIGNAL_EVENT

## 1-3 보유종목(Holdings)
- 목적: 보유 포지션/손익/상태(원금회수/추세추종 등) 확인 및 조치
- 입력: 보유 목록, 평가기준
- 출력: 상태, 경고, 액션(부분익절/스탑업 등)
- 연관 로직: 2-4 보유 종목 관리
- 연관 DB: (추후) 보유/트레이드 테이블

## 1-4 차트(Chart)
- 목적: 분석 결과(ENTRY/STOP/TP, 신호, 이벤트)를 시각적으로 확인
- 입력: 종목코드/기간/옵션
- 출력: 차트 오버레이(ENTRY/STOP/TP1) + 신호/이벤트 마커(확장)
- 연관 로직: 2-2 차트 분석 모듈, 2-5 차트 표시 항목
