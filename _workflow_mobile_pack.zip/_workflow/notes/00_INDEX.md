# Scheduler Workflow Index

## 목적
- 추천 정확도 개선(백테스트/튜닝) 및 MFE/MAE 기반 검증 루프를 **워크플로우로 시각화**해서 운영.

## 바로가기
- 캔버스: `../canvas/PROJECT_FLOW.canvas`
- 진행 로그(코드 저장소): `../PROGRESS_LOG.md`
- 프로젝트 플랜(코드 저장소): `../PROJECT_PLAN.md`

## 상태 표기 규칙
- ✅ 완료
- 🟡 진행중/부분완료
- ⬜ 미착수
- ⚠️ 리스크/운영주의

## 현재 우선순위
1. W1 추천 스냅샷 저장(Reco Snapshot) ⬜
2. W2 거래일 캘린더 확정/생성 ⬜
3. W3 Return + MFE/MAE 계산 및 DB 저장 ⬜
4. W4 분해 분석(레짐/신호/이벤트 조합) ⬜
5. W5 튜닝 실험 프레임(파라미터/실험ID/성과 비교) ⬜
